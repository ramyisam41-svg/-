ملك الطعمية - GitHub upload package

IMPORTANT:
- Upload the CONTENTS of this folder to the GitHub repository, not this ZIP itself.
- Do not upload the SQLite database or secrets.
- After upload, we will connect the repository to the online API hosting service.
