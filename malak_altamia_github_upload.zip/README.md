# ملك الطعمية — Full Stack API + App

هذه النسخة تربط واجهة الطلب بواجهة API وقاعدة SQLite. Express يخدم ملفات التطبيق من مجلد public، والطلب الذي يرسله العميل يُحفظ في قاعدة البيانات.

## التشغيل
1. ثبّت Node.js 18+.
2. افتح المجلد في الطرفية.
3. نفّذ: `npm install`
4. نفّذ: `npm start`
5. افتح: `http://localhost:3000`

للهاتف على نفس شبكة Wi‑Fi: افتح عنوان IP لجهاز الكمبيوتر على المنفذ 3000، مثل `http://IP-الكمبيوتر:3000`.

## الاختبار
- اختر كمية.
- أضف الإضافات.
- أدخل الاسم والهاتف والعنوان.
- اضغط «اطلب الآن».
- سيظهر رقم الطلب وحالته، وسيُحفظ الطلب في `malak_altamia.sqlite3`.

## API
- GET `/api/health`
- GET `/api/shop`
- GET `/api/products`
- GET `/api/addons`
- POST `/api/orders`
- GET `/api/orders`
- GET `/api/orders/:id`
- PATCH `/api/orders/:id/status`
- GET `/api/reports/today`

ملاحظة: هذه نسخة اختبار محلية. قبل نشرها على الإنترنت يجب إضافة تسجيل دخول للمالك، HTTPS، نسخ احتياطية وحماية أقوى للـAPI.
